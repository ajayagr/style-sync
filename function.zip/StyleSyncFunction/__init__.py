"""
StyleSync Azure Function - Minimal Test Version
"""
import azure.functions as func
import json
import logging


def main(req: func.HttpRequest) -> func.HttpResponse:
    """Minimal test function to verify basic connectivity."""
    logging.info("StyleSync test function triggered")
    
    try:
        # Step 1: Basic response
        result = {"step": "basic", "status": "ok"}
        
        # Step 2: Parse JSON body
        try:
            body = req.get_json()
            result["body_received"] = body
            result["step"] = "json_parse"
        except ValueError:
            result["body_error"] = "Invalid JSON"
        
        # Step 3: Check environment variables
        import os
        result["env_check"] = {
            "AZURE_STORAGE_CONNECTION_STRING": "set" if os.environ.get("AZURE_STORAGE_CONNECTION_STRING") else "missing",
            "AZURE_API_KEY": "set" if os.environ.get("AZURE_API_KEY") else "missing",
            "AZURE_ENDPOINT_URL": "set" if os.environ.get("AZURE_ENDPOINT_URL") else "missing",
            "CONTAINER_NAME": os.environ.get("CONTAINER_NAME", "not set")
        }
        result["step"] = "env_check"
        
        # Step 4: Test Azure Blob Storage import
        try:
            from azure.storage.blob import BlobServiceClient
            result["blob_import"] = "ok"
            result["step"] = "blob_import"
        except ImportError as e:
            result["blob_import"] = f"failed: {e}"
            return func.HttpResponse(json.dumps(result, indent=2), status_code=200, mimetype="application/json")
        
        # Step 5: Test storage connection
        conn_str = os.environ.get("AZURE_STORAGE_CONNECTION_STRING")
        if conn_str:
            try:
                client = BlobServiceClient.from_connection_string(conn_str)
                container = client.get_container_client(os.environ.get("CONTAINER_NAME", "file-container"))
                blobs = list(container.list_blobs(name_starts_with="source"))[:5]
                result["storage_test"] = {
                    "connected": True,
                    "blobs_found": [b.name for b in blobs]
                }
                result["step"] = "storage_connected"
            except Exception as e:
                result["storage_test"] = {"error": str(e)}
        else:
            result["storage_test"] = "no connection string"
        
        result["status"] = "all_tests_passed"
        
        return func.HttpResponse(
            json.dumps(result, indent=2),
            status_code=200,
            mimetype="application/json"
        )
        
    except Exception as e:
        logging.error(f"Error: {e}")
        return func.HttpResponse(
            json.dumps({"error": str(e), "type": type(e).__name__}),
            status_code=500,
            mimetype="application/json"
        )
